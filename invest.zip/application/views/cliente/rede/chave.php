<div class="col-md-12">
              <div class="card ">
                <div class="card-header card-header-success card-header-text">
                  <div class="card-text">
                    <h4 class="card-title">Chave binária</h4>
                  </div>
                </div>
                <div class="card-body ">
           <div class="alert text-center">Altere a chave binária e controle cada usuário em sua rede.</div>
                  
           <div class="row">
               <form class="form-horizontal form-variance">
               <div class="col-sm-5 checkbox-radios">
                   <div class="col-md-3"><div class="form-group bmd-form-group">
                        <div class="form-check">
                          <label class="form-check-label">
                            <input class="form-check-input" type="radio" name="chave_binaria" id="chave_binaria" value="1" <?php echo (InformacoesUsuario('chave_binaria') == 1) ? 'checked=""' : '';?>>
                            Esquerda
                            <span class="circle">
                              <span class="check"></span>
                            </span>
                          </label>
                        </div></div></div>
                   <div class="col-md-3"><div class="form-group bmd-form-group">

                        <div class="form-check">
                          <label class="form-check-label">
                            <input class="form-check-input" type="radio" name="chave_binaria" id="chave_binaria" value="2" <?php echo (InformacoesUsuario('chave_binaria') == 2) ? 'checked=""' : '';?>>
                            Direita
                            <span class="circle">
                              <span class="check"></span>
                            </span>
                          </label>
                        </div></div></div>
                        
                      </div>
           </form></div>
                    </div>
                      </div>
                    </div>
                   
                  </form>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5faebd460863900e88c86f11/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->